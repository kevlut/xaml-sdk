This example shows how to add RadAutoCompleteBox insize GridViewDataColumn for Silverlight and WPF.

The 'Country' column in the RadGridView uses the AutoCompleteBox control."
