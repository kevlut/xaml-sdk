This example demonstrates how to use RadAutoCompleteBox inside RadDataForm by creating a custom ReadOnlyTemplate, EditTemplate
and NewItemTemplate for Silverlight and WPF.