﻿
namespace WithDataForm
{
	public class Country
	{
		public string Name { get; set; }

		public string Capital { get; set; }
	}
}
