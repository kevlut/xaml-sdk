﻿using System.Windows.Controls;

namespace CustomDropDownItemTemplate
{
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
