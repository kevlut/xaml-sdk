﻿
namespace CustomDropDownItemTemplate
{
	public class Country
	{
		public string Name { get; set; }

		public string Capital { get; set; }

		public int Id { get; set; }
	}
}
