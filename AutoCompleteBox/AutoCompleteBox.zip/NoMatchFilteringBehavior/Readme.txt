This example demonstrates how to customize the FilteringBehavior of the cotnrol for Silverlight and WPF.

With the custom filtering behavior if the control has the focus or there isn't a matched item when typing in the control 
the drop down portion of the control will be populated with the entire ItemsSource collection. Try typing in for example 
'London', the drop down will be populated no matter that there isn't a matched item.