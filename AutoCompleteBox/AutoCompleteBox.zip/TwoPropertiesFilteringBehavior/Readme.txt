This example demonstrates how to customize the FilteringBehavior of the control for Silverlight and WPF.

For example type U (for United States) then ',' and then W (for Washington, D.C.), this will generate 
Unites States in the drop down portion of the control.