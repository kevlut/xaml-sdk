﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwoPropertiesFilteringBehavior
{
	public class Country
	{
		public string Name { get; set; }

		public string Capital { get; set; }
	}
}
