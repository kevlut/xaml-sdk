﻿namespace AppointmentsReminders
{
    /// <summary>
    /// Interaction logic for ReminderWindow.xaml
    /// </summary>
    public partial class ReminderWindow 
    {
        public ReminderWindow()
        {
            InitializeComponent();
        }
    }
}
