This example illustrates how you can choose which special slot to stay on top of the other by setting its ZIndex.
There is a possible approach the ZIndex to be bound in order to be manipulated from the ViewModel.
The button changes the ZIndex of the ReadOnlySlot in DayView, WeekView and Timeline.
The ZIndex of the NonWorkingHourSlots is bound to the ViewModel statically for MonthView.