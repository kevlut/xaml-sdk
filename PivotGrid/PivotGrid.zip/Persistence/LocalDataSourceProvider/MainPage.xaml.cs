﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace Persistence
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
