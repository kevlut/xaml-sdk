﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExportPivotGrid
{
    public class ExportType
    {
        public Uri ImageSource { get; set; }
        public string ExportFormat { get; set; }
    }
}
