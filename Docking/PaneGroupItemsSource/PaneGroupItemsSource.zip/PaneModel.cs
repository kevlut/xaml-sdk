﻿
namespace PaneGroupItemsSource
{
	public class PaneModel
	{
		public string Header { get; set; }

		public string Content { get; set; }
	}
}
