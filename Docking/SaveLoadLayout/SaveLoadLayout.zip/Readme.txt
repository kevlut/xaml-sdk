This example demonstrates how the Save/Load layout functionality work in the RadDocking control. 
If a Panes content/properties needs to be persisted when the layout is saved setting the 
SerializationTag is required. In order to exclude a Pane from the Save layout functionality 
setting the ExcludedFromLayoutSave is required.