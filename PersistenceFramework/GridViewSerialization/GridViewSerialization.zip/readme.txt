This example demonstrates custom serialization of properties for the RadGridView control.
Sorting and Grouping, width and position of the columns will be serialized.