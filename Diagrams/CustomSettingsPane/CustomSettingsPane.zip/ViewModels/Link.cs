﻿using System;
using System.Linq;

namespace CustomSettingsPane.ViewModels
{
	public class Link : Telerik.Windows.Controls.Diagrams.Extensions.ViewModels.LinkViewModelBase<ShapeViewModel>
	{
		public override string ToString()
		{
			return "";
		}
	}
}
