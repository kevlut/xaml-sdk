The CustomSettingsPane example highlights the following features of RadDiagram and DiagramExtensions:
	-Binding the DiagramToolBox
	-Drawing Tools in MVVM Diagram
	-Customizing Settings Pane:
		-Adding new tabs
		-Binding to ViewModel's properties
		-Binding to App's MainViewModel's Commands
		-Adding custom shapes in toolbox from SettingsPane