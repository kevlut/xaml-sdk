﻿using System.Collections.ObjectModel;
using Telerik.Windows.Controls.Diagrams.Extensions.ViewModels;

namespace MVVM
{
	public class Brand : ContainerNodeViewModelBase<object>
	{
	}
}
