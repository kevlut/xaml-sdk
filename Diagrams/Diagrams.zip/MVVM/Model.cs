﻿using Telerik.Windows.Controls.Diagrams.Extensions.ViewModels;

namespace MVVM
{
	public class Model : NodeViewModelBase
	{

	}
}
