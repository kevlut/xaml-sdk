The sample demonstrates that you can easily use RadDiagram framework using the MVVM pattern. 
It could serve as a starting point for your MVVM based Diagram applications.