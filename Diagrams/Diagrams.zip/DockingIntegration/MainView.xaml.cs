﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace DockingIntegration
{
    /// <summary>
    /// Interaction logic for MainView.xaml
    /// </summary>
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
