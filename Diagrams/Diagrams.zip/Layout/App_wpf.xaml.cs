﻿using System;
using System.Windows;

namespace Diagrams.Layout
{
	public class App : Application
	{

	 
	}
}
