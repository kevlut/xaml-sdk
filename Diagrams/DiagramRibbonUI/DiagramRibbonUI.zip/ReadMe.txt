﻿The sample demonstrates how to create RibbonUI for most of the Diagramming framework functionality.
The sample can be used for first steps to any Diagramming application. 
It is a strip version of the QSF Diagrams FirstLook sample.