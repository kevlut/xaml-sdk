﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class DesaturationColorizerExample : UserControl
	{
		public DesaturationColorizerExample()
		{
			InitializeComponent();
		}
	}
}
