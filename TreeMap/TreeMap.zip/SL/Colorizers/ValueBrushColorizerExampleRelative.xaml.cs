﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class ValueBrushColorizerExample_Relative : UserControl
	{
		public ValueBrushColorizerExample_Relative()
		{
			InitializeComponent();
		}
	}
}
