﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class ValueBrushColorizerExampleRelative : UserControl
	{
		public ValueBrushColorizerExampleRelative()
		{
			InitializeComponent();
		}
	}
}
