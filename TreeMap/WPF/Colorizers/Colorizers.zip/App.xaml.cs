﻿using System.Windows;

namespace Colorizers
{
	public partial class App : Application
	{
	}
}
