This example demonstrates how to create a custom DragVisualProvider in order to change its Foreground, Background, BorderBrush and Template for
Silverlight and WPF.