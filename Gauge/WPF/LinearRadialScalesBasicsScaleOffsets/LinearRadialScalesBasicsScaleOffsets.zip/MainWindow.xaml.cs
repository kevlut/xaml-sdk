﻿using System.Windows;

namespace LinearRadialScalesBasicsScaleOffsets
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
