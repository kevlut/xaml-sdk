﻿using System.Windows;

namespace LinearRadialScalesLinearScaleOrientation
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
