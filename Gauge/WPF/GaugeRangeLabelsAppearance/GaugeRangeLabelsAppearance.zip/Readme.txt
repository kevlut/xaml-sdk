﻿The appearance of the labels in the range can be controlled via the following properties:

   - LabelForeground - specifies the foreground color for the labels that belong to the range.
	
To modify the appearance of the labels via the range, they should be in Use Range Color mode.