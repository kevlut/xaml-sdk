﻿using System.Windows;

namespace LinearRadialScalesRadialScaleStartAngle
{
	public partial class App : Application
	{
	}
}
