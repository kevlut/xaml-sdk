﻿using System.Windows;

namespace LinearScaleTickMarks
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
