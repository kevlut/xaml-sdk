﻿using System.Windows;

namespace LinearScaleNumericIndicator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
