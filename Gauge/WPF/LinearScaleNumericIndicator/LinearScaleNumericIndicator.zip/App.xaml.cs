﻿using System.Windows;

namespace LinearScaleNumericIndicator
{
	public partial class App : Application
	{
	}
}
