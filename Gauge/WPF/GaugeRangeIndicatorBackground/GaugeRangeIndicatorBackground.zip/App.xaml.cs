﻿using System.Windows;

namespace GaugeRangeIndicatorBackground
{
	public partial class App : Application
	{
	}
}
