﻿using System.Windows;

namespace LinearRadialScalesRadialScaleScaleCenter
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
