﻿using System.Windows;

namespace RadialScaleOverview
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
