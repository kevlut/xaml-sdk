﻿using System.Windows;

namespace NumericScaleStateIndicator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
