﻿using System.Windows;

namespace NumericScaleStateIndicator
{
	public partial class App : Application
	{
	}
}
