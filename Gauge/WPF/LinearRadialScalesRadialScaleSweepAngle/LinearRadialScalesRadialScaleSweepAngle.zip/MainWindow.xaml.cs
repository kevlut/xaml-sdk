﻿using System.Windows;

namespace LinearRadialScalesRadialScaleSweepAngle
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
