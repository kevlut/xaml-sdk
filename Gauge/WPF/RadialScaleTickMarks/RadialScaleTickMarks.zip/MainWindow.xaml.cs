﻿using System.Windows;

namespace RadialScaleTickMarks
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
