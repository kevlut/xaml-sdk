﻿using System.Windows;

namespace RadialScaleSemiCircleGauge
{
	public partial class App : Application
	{
	}
}
