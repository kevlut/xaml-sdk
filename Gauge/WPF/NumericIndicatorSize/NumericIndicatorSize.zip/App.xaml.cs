﻿using System.Windows;

namespace NumericIndicatorSize
{
	public partial class App : Application
	{
	}
}
