﻿using System.Windows;

namespace RadialScaleInteractivity
{
	public partial class App : Application
	{
	}
}
