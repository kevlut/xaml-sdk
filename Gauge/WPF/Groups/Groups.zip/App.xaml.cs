﻿using System.Windows;

namespace Groups
{
	public partial class App : Application
	{
	}
}
