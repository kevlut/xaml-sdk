﻿using System.Windows;

namespace HowToCreateCompass
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
