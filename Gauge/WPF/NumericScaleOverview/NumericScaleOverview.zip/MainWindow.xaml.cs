﻿using System.Windows;

namespace NumericScaleOverview
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
