﻿using System.Windows;

namespace IndicatorsMarker
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
