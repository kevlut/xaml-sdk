﻿using System.Windows;

namespace TicksAppearance
{
	public partial class App : Application
	{
	}
}
