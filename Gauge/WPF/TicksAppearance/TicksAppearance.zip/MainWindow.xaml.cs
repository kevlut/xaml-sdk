﻿using System.Windows;

namespace TicksAppearance
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
