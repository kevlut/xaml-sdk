﻿using System.Windows;

namespace RadialScaleBarIndicatorAppearance
{
	public partial class App : Application
	{
	}
}
