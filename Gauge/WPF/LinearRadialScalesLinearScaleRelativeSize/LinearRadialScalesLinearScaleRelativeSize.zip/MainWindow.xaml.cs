﻿using System.Windows;

namespace LinearRadialScalesLinearScaleRelativeSize
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
