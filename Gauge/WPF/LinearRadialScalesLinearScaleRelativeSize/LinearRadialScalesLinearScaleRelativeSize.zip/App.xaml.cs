﻿using System.Windows;

namespace LinearRadialScalesLinearScaleRelativeSize
{
	public partial class App : Application
	{
	}
}
