﻿using System.Windows;

namespace LinearScaleStateIndicator
{
	public partial class App : Application
	{
	}
}
