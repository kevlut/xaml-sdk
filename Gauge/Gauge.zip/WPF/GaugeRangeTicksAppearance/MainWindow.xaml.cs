﻿using System.Windows;

namespace GaugeRangeTicksAppearance
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
