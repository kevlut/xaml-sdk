﻿using System.Windows;

namespace LabelsFormat
{
	public partial class App : Application
	{
	}
}
