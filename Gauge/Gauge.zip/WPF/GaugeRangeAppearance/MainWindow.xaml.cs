﻿using System.Windows;

namespace GaugeRangeAppearance
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
