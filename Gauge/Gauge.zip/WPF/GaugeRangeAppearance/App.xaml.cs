﻿using System.Windows;

namespace GaugeRangeAppearance
{
	public partial class App : Application
	{
	}
}
