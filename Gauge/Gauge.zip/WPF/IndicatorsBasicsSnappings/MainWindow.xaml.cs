﻿using System.Windows;

namespace IndicatorsBasicsSnapping
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
