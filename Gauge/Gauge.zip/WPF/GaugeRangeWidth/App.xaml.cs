﻿using System.Windows;

namespace GaugeRangeWidth
{
	public partial class App : Application
	{
	}
}
