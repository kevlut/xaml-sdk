﻿using System.Windows;

namespace CreatingLinearGauge
{
	public partial class App : Application
	{
	}
}
