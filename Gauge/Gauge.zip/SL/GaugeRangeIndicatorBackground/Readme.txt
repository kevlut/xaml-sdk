﻿You can specify an appearance for the scale's indicator, when it enters inside the range. This is done by using the following of the range object's properties:

  - IndicatorBackground
  - IndicatorColorMixSensitivity

To modify the appearance of the indicator via the range, the indicator should be in Use Range Color mode.