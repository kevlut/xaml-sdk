﻿The RadialScale and LinearScale objects which inherit the GraphicScale class provide you with two ways of modifying the labels' appearance:

  - Modifying Label's Foreground
  - Specifying a LabelTemplate