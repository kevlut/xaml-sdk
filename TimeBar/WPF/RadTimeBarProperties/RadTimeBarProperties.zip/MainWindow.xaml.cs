﻿using System.Windows;

namespace RadTimeBarProperties
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
