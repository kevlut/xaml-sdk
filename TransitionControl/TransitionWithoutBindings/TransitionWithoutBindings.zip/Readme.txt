This example demonstrates how to use RadTransitionControl between two UserControls (without bindings set to the RadTransitionControl)
for Silverlight and WPF.