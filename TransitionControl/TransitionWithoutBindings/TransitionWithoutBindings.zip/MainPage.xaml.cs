﻿using System.Windows.Controls;

namespace TransitionWithoutBindings
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
