﻿using System.Windows.Controls;

namespace TransitionWithoutBindings
{
	public partial class ScheduleView : UserControl
	{
		public ScheduleView()
		{
			InitializeComponent();
		}
	}
}
