﻿using System.Windows.Controls;

namespace TransitionWithoutBindings
{
	public partial class Docking : UserControl
	{
		public Docking()
		{
			InitializeComponent();
		}
	}
}
