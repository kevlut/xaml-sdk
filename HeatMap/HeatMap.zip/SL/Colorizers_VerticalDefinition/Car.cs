﻿namespace Colorizers_VerticalDefinition
{
	public class Car
	{
		public string Name { get; set; }
		public int MilesPerGallon { get; set; }
		public int TopSpeed { get; set; }
		public int Price { get; set; }
		public int HorsePower { get; set; }
	}
}
