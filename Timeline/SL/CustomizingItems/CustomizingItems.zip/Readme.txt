﻿There are two ways you can change the template for the RadTimeline items. You can either customize them with the use of ItemTemplateSelector, or with a TimelineItemTemplate / TimelineInstantItemTemplate property. This example will walk you through these two approaches:

  - TimelineItemTemplate / TimelineInstantItemTemplate property
  - ItemTemplateSelector