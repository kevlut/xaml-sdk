﻿The timeline items in a RadTimeline control can be displayed in groups. Additionally, groups of timeline items can be made expandable/collapsible.
This example demonstrates the following:

  - Properties
  - Group Expand Modes
  - Changing the default collapsed state of expandable groups