﻿using System;

namespace DataBinding
{
	public class Item
	{
		public TimeSpan Duration { get; set; }
		public DateTime Date { get; set; }
	}
}
