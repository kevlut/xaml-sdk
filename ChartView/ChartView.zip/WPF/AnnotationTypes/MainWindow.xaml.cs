﻿using System.Windows;

namespace AnnotationTypes
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
