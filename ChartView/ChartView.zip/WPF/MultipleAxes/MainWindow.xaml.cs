﻿using System.Windows;

namespace MultipleAxes
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
