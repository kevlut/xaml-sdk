﻿using System.Windows;

namespace CustomizingScatterPoints
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
