﻿using System.Windows;

namespace ScrollAndZoom
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
