﻿using System;

namespace ScrollAndZoomSyncedCharts
{
    public class UsersData
    {
        public DateTime Date { get; set; }
        public int UsersCount { get; set; }
    }
}
