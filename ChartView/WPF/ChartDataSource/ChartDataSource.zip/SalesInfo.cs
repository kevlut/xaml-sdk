﻿using System;

namespace ChartDataSource
{
	public class SalesInfo
	{
		public DateTime Time { get; set; }
		public int Value { get; set; }
	}
}
