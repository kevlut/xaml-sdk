﻿using System.Windows;

namespace AnnotationsAdding
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
