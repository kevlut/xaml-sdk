﻿using System.Windows.Controls;

namespace CustomHeaderTemplate
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
