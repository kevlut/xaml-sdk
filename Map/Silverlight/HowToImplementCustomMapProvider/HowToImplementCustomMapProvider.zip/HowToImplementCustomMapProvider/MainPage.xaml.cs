﻿using System.Windows.Controls;

namespace HowToImplementCustomMapProvider
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
