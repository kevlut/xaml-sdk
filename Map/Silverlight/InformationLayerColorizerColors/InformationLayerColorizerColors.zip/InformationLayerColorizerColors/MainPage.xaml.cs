﻿using System.Windows.Controls;

namespace InformationLayerColorizerColors
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
