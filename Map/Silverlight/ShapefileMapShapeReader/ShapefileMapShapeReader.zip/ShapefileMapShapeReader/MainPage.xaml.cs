﻿using System.Windows.Controls;

namespace ShapefileMapShapeReader
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
