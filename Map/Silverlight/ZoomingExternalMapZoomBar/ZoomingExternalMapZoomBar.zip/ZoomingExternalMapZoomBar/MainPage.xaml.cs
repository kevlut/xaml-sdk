﻿using System.Windows.Controls;

namespace ZoomingExternalMapZoomBar
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
