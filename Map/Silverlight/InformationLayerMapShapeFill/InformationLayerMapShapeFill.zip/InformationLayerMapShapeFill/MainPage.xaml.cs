﻿using System.Windows.Controls;

namespace InformationLayerMapShapeFill
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
