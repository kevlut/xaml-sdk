﻿using System.Windows;

namespace ProvidersUriImageProvider
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
