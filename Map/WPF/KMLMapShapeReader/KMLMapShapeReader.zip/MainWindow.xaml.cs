﻿using System.Windows;

namespace KMLMapShapeReader
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
