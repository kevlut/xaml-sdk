﻿using System.Windows;

namespace ExternalMapMouseLocationIndicator
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
