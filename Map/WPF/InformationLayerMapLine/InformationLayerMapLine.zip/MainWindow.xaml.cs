﻿using System.Windows;

namespace InformationLayerMapLine
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
