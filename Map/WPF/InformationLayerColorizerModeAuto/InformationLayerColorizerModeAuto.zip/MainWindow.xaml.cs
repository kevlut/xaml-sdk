﻿using System.Windows;

namespace InformationLayerColorizerModeAuto
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
