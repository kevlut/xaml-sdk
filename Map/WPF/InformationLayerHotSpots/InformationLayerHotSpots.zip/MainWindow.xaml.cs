﻿using System.Windows;

namespace InformationLayerHotSpots
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
