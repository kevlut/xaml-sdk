﻿using System.Windows;

namespace MapShapeReaderToolTipTemplate
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
