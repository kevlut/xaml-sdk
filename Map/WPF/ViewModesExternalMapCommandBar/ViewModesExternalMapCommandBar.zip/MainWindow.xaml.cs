﻿using System.Windows;

namespace ViewModesExternalMapCommandBar
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
