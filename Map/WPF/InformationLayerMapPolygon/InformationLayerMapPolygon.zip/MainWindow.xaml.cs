﻿using System.Windows;

namespace InformationLayerMapPolygon
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
