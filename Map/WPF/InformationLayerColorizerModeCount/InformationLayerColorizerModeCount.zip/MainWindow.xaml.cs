﻿using System.Windows;

namespace InformationLayerColorizerModeCount
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
