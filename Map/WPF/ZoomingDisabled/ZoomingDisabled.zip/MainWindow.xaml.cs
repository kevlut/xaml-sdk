﻿using System.Windows;

namespace ZoomingDisabled
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
