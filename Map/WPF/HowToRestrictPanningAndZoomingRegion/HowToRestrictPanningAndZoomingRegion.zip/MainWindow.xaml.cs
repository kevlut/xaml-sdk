﻿using System.Windows;

namespace HowToRestrictPanningAndZoomingRegion
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
