﻿using System.Windows;

namespace DistanceAndScaleDistanceUnit
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
