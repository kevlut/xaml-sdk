﻿using System.Windows;

namespace SQLGeospatialData
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
