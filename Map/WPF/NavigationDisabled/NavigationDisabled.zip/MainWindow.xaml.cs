﻿using System.Windows;

namespace NavigationDisabled
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
