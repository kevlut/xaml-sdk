﻿using System.Windows.Controls;

namespace NavigationExternalMapNavigation
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
