﻿using System.Windows.Controls;

namespace MapLegend
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
