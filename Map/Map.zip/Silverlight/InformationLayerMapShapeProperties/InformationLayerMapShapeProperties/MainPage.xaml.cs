﻿using System.Windows.Controls;

namespace InformationLayerMapShapeProperties
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
