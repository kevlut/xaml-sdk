﻿using System.Windows.Controls;

namespace InformationLayerMapShapeMapShapeFill
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
