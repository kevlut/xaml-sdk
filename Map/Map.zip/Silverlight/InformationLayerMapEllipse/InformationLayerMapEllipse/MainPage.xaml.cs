﻿using System.Windows.Controls;

namespace InformationLayerMapEllipse
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
