﻿using System.Windows.Controls;

namespace InformationLayerColorizerModeRanges
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
