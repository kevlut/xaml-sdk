This example demonstrates how to customize the Style of the DateTimePicker in order to add a today button to the RadDateTimePicker control for
Silverlight and WPF.