﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace Watermark
{
    /// <summary>
    /// Interaction logic for TelerikEditor.xaml
    /// </summary>
    public partial class TelerikEditor : UserControl
    {
        public TelerikEditor()
        {
            InitializeComponent();
        }
    }
}
