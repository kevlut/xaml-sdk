﻿using System;
using System.Linq;
using Telerik.Windows.Controls;

namespace ToolBarMVVM
{
	public class SeparatorViewModel : ViewModelBase
	{
	}
}
