﻿using System.Windows;

namespace CreatingABulletGraphProgrammatically
{
	public partial class App : Application
	{
	}
}
