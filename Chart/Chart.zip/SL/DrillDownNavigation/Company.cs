﻿namespace DrillDownNavigation
{
    public class Company
    {
        public string Name
        {
            get;
            set;
        }

        public ModelSalesCollection Sales
        {
            get;
            set;
        }
    }
}
