﻿using System.Windows.Controls;

namespace ChartLegend
{
	public partial class AutomaticLegendItemsGeneration : UserControl
	{
		public AutomaticLegendItemsGeneration()
		{
			InitializeComponent();
		}
	}
}
