﻿using System;

namespace ChartTitle
{
	public class ChartData
	{
		public DateTime Date { get; set; }
		public int Turnover { get; set; }
		public int Expenses { get; set; }
	}
}
