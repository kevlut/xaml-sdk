﻿namespace LayoutMode
{
	public class ChartData
	{
		public int XCat { get; set; }
		public double YVal { get; set; }
	}
}
