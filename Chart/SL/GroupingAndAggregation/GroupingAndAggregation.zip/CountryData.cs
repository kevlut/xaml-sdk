﻿namespace GroupingAndAggregation
{
    public class CountryData
    {
        public int Year { get; set; }
        public string Region { get; set; }
        public string Description { get; set; }
        public int Value { get; set; }
    }
}
