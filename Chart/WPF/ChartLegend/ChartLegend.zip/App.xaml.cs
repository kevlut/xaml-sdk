﻿using System.Windows;

namespace ChartLegend
{
	public partial class App : Application
	{
	}
}
