﻿namespace DataBindingToManyChartAreas
{
	public class ChartData
	{
		public string Description { get; set; }
		public int Value { get; set; }
	}
}
