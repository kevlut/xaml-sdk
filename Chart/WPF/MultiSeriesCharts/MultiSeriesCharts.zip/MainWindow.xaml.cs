﻿using System.Windows;

namespace MultiSeriesCharts
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
