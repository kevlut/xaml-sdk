﻿This tutorial will walk you through the creation of a RadChart and will show how to:

  - Create and bind SplineChart to collection of custom objects using SeriesMapping/ItemMapping
  - Create categorical chart