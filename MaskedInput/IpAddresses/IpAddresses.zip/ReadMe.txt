The example shows a RadMaskedTextInput controls configured to suite as an IP Address Input Boxes.
Once the full IP Address is writted down, a validation logic in the ViewModel is triggered.
If the Ip Address is not Valid, a validation Error Message is displayed among with a Validation ToolTip.