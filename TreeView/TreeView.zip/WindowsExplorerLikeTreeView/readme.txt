This project is available only for WPF because in Silverlight we do not have access to the file system.

Description:
This project demonstrates how you can create a TreeView similar to the Windows Explorer's one. The application traverses the file system of the user and displays all available drives, folders and files. Also it applies different styles to the different items.