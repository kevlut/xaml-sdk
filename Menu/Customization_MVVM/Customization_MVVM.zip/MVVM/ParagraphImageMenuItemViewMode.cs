﻿
namespace Customization_MVVM
{
	public class ParagraphImageMenuItemViewMode : MenuViewModel
	{
		public string Image { get; set; }
		public string Title { get; set; }
		public string Summary { get; set; }

		public ParagraphImageMenuItemViewMode()
		{
		}
	}
}
