﻿
using System.Collections.ObjectModel;
namespace Customization_MVVM
{
	public class MenuViewModel : ObservableCollection<MenuViewModel>
	{
	}
}
