﻿using System.Windows;

namespace DataBarProperties
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
