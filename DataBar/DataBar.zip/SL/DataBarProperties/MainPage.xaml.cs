﻿using System.Windows.Controls;

namespace DataBarProperties
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
