This project demonstrates how to create, edit and delete a dependency to a Task in the RadGanttView control using an AutoCompleBox control for Silverlight and WPF.
