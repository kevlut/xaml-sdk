﻿using System.Windows.Media.Imaging;

namespace PrintingAndExportingAdvanced
{
	public class PreviewPage
	{
		public BitmapSource BitmapSource { get; set; }

		public int PageNumber { get; set; }
	}
}
