﻿using System.Windows.Controls;

namespace CustomCellTemplates
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
