﻿using System.Windows.Controls;

namespace ZeroTaskLevelInitiallyCollapsed
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
