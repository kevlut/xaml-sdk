This example demonstrates how to create a custom InitialExpandBehavior that will collapse the 'Big Iteration' task and expand its children tasks
The example is available for Silverlight and WPF.