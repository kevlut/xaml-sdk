﻿using System.Windows.Controls;

namespace CustomGanttTaskWithStatus
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
