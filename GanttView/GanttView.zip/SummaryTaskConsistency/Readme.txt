This example demonstrates how to achieve consistency between inner tasks and their parent Summary task. 
If a border's task Start/End property are changed the Summary task's Start/End properties will be updated accordingly.

This example is available for Silverlight and WPF.