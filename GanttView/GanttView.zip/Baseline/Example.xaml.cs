﻿using System.Windows.Controls;

namespace Baseline
{
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
